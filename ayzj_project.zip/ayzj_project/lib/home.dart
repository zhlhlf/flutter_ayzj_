import 'package:flutter/material.dart';
import './toktik/vide.dart';
import './qr_code.dart';

class myapp extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => myapp1();
}

class myapp1 extends State<myapp> {
  @override
  int _currentIndex = 0;

  Widget build(BuildContext context) {
    return Scaffold(
/*       backgroundColor: Colors.black, */
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        backgroundColor: Color.fromARGB(255, 126, 232, 232),
        currentIndex: _currentIndex,
        items: const [
          BottomNavigationBarItem(
            icon: Icon(
              Icons.video_call,
              color: Color.fromARGB(255, 152, 239, 230),
            ),
            label: "视频",
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.shop,
              color: Color.fromARGB(255, 152, 239, 230),
            ),
            label: "服务",
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.shop,
              color: Color.fromARGB(255, 152, 239, 230),
            ),
            label: "我要发表",
          ),
          BottomNavigationBarItem(
            icon: Icon(
              Icons.android,
              color: Color.fromARGB(255, 152, 239, 230),
            ),
            label: "我的",
          ),
        ],
        onTap: (value) {
          setState(() {
            _currentIndex = value;
          });
        },
      ),
      body: homeindex[_currentIndex],
    );
  }
}

List<Widget> homeindex = [
  home1(),
  fw(),
  const Center(child: Text("待开发")),
  MyHome()
];

class home1 extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => home11();
}

class home11 extends State<home1> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  @override
  void initState() {
    super.initState();
    _tabController = new TabController(length: 2, vsync: this);
  }

  Widget build(BuildContext context) {
    return Stack(children: [
      TabBarView(controller: _tabController, children: [
        videpage(),
        const Center(child: Text("待开发")),
      ]),
      SizedBox(
          height: 50,
          width: 120,
          child: TabBar(
            indicatorSize: TabBarIndicatorSize.label,
            indicatorColor: const Color.fromARGB(255, 76, 246, 223),
            controller: _tabController,
            tabs: const [
              Tab(
                  child: Text(
                "视频",
                style: TextStyle(color: Colors.pinkAccent),
              )),
              Tab(
                  child: Text(
                "消息",
                style: TextStyle(color: Colors.pinkAccent),
              )),
            ],
          )),
    ]);
  }
}

class fw extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => fw1();
}

class fw1 extends State<fw> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  @override
  void initState() {
    super.initState();
    _tabController = new TabController(length: 2, vsync: this);
  }

  Widget build(BuildContext context) {
    return Stack(children: [
      SizedBox(
          height: 50,
          width: 120,
          child: TabBar(
            indicatorSize: TabBarIndicatorSize.label,
            indicatorColor: const Color.fromARGB(255, 76, 246, 223),
            controller: _tabController,
            tabs: const [
              Tab(
                  child:
                      Text("服务", style: TextStyle(color: Colors.pinkAccent))),
              Tab(
                  child:
                      Text("采集", style: TextStyle(color: Colors.pinkAccent))),
            ],
          )),
      TabBarView(controller: _tabController, children: [
        const Center(child: Text("待开发")),
        const Center(child: Text("待开发")),
      ]),
    ]);
  }
}
