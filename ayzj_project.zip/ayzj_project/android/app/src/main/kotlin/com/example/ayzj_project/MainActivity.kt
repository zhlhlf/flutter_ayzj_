package com.example.ayzj_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
