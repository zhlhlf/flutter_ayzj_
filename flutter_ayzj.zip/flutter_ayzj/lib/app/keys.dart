// ignore_for_file: constant_identifier_names

class Keys {
  /// APP相关设置的Hive Box名称
  static const SETTINGS_BOX_NAME = "DmzjSettings";

  /// 主题模式
  static const SETTINGS_THEME_MODE = "ThemeMode";

  /// 主题颜色
  static const SETTINGS_THEME_COLOR = "ThemeColor";
}
