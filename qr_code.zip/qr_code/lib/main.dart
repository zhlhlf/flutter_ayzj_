import "package:flutter/material.dart";
import './qr_code.dart';

void main() => runApp(MaterialApp(home: myapp()));

class myapp extends StatelessWidget {
  List<Widget> qq = [
    MyHome(),
    const Text("saf"),
    const Text("saf"),
    const Text("saf"),
    const Text("saf"),
  ];
  int uu = 0;

  Widget build(BuildContext context) {
    return Scaffold(
      body: qq[uu],
      bottomNavigationBar: BottomNavigationBar(
          backgroundColor: Colors.lightBlue,
          type: BottomNavigationBarType.fixed,
          currentIndex: uu,
          items: [
            BottomNavigationBarItem(icon: Icon(Icons.home), label: "sdf"),
            BottomNavigationBarItem(icon: Icon(Icons.home), label: "sdf"),
            BottomNavigationBarItem(icon: Icon(Icons.home), label: "sdf"),
            BottomNavigationBarItem(icon: Icon(Icons.home), label: "sdf"),
            BottomNavigationBarItem(icon: Icon(Icons.home), label: "sdf"),
          ]),
    );
  }
}
